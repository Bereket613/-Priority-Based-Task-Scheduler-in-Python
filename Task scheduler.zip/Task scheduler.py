import heapq
import os
import re
from datetime import datetime

def get_user_input(prompt):
    return input(f"{prompt}: ").strip()

def get_valid_priority():
    while True:
        priority = get_user_input("Enter task priority (1=high, 3=low)")
        if priority in ("1", "3"):
            return int(priority)
        print("Invalid priority! Please enter 1 or 3.")

def get_valid_deadline():
    while True:
        deadline = get_user_input("Enter deadline (YYYY-MM-DD)")
        try:
            datetime.strptime(deadline, "%Y-%m-%d")  # Check if the date is in the correct format
            return deadline
        except ValueError:
            print("Invalid date format! Please enter in YYYY-MM-DD format.")

def get_valid_task_name():
    while True:
        name = get_user_input("Enter task name")
        if re.match("^[A-Za-z ]*$", name):  # Only allows letters and spaces
            return name
        print("Task name can only contain letters and spaces, no numbers or special characters!")

class Task:
    def __init__(self, task_id, name, priority, deadline):
        self.task_id = task_id
        self.name = name
        self.priority = priority
        self.deadline = deadline

    def __lt__(self, other):
        """Allows comparison for heapq (priority-based sorting)"""
        return self.priority < other.priority  

    def __repr__(self):
        return f"Task(ID: {self.task_id}, Name: {self.name}, Priority: {self.priority}, Deadline: {self.deadline})"

class TaskScheduler:
    FILE_PATH = r"C:\Users\13309\Desktop\New folder\python\DSA project\tasks.txt"  
    
    def __init__(self):
        self.task_list = []
        self.task_counter = 0
        self.load_tasks()
    
    def add_task(self, name, priority, deadline):
        self.task_counter += 1
        task = Task(self.task_counter, name, priority, deadline)
        heapq.heappush(self.task_list, (priority, task))  # Priority Queue
        self.save_tasks()
        print(f"Task '{name}' added successfully.")

    def remove_task(self):
        if self.task_list:
            _, task = heapq.heappop(self.task_list)
            self.save_tasks()
            print(f"Task '{task.name}' removed.")
        else:
            print("No tasks to remove.")
    
    def display_tasks(self):
        if not self.task_list:
            print("No tasks available.")
        else:
            print("\nTask List (by priority):")
            for _, task in self.task_list:
                print(task)
    
    def display_tasks_sorted(self):
        if not self.task_list:
            print("No tasks available.")
        else:
            sorted_tasks = self.task_list[:]
            self.insertion_sort(sorted_tasks)
            print("\nSorted Task List (by Deadline):")
            for _, task in sorted_tasks:
                print(task)
    
    def save_tasks(self):
        try:
            with open(self.FILE_PATH, "w") as file:
                file.writelines(f"{task.task_id}, {task.name}, {task.priority}, {task.deadline}\n" for _, task in self.task_list)
        except Exception as e:
            print(f"Error saving tasks: {e}")
    
    def load_tasks(self):
        if os.path.exists(self.FILE_PATH):
            try:
                with open(self.FILE_PATH, "r") as file:
                    for line in file:
                        parts = line.strip().split(", ")
                        if len(parts) == 4:
                            task_id, name, priority, deadline = int(parts[0]), parts[1], int(parts[2]), parts[3]
                            heapq.heappush(self.task_list, (priority, Task(task_id, name, priority, deadline)))
                            self.task_counter = max(self.task_counter, task_id)
                print("Tasks loaded successfully.")
            except Exception as e:
                print(f"Error loading tasks: {e}")

    def insertion_sort(self, tasks):
        for i in range(1, len(tasks)):
            key_task = tasks[i]
            j = i - 1
            while j >= 0 and datetime.strptime(tasks[j][1].deadline, "%Y-%m-%d") > datetime.strptime(key_task[1].deadline, "%Y-%m-%d"):
                tasks[j + 1] = tasks[j]
                j -= 1
            tasks[j + 1] = key_task

def menu():
    scheduler = TaskScheduler()
    
    while True:
        print("\nTask Scheduler Menu:")
        print("1. Add Task")
        print("2. Remove Task")
        print("3. Display Tasks (Priority Order)")
        print("4. Display Tasks (Sorted by Deadline)")
        print("5. Exit")
        
        choice = get_user_input("Enter your choice")

        if choice == '1':
            name = get_valid_task_name()  
            priority = get_valid_priority()
            deadline = get_valid_deadline()
            scheduler.add_task(name, priority, deadline)

        elif choice == '2':
            scheduler.remove_task()

        elif choice == '3':
            scheduler.display_tasks()

        elif choice == '4':
            scheduler.display_tasks_sorted()

        elif choice == '5':
            print("Exiting Task Scheduler. Goodbye!")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    menu()
